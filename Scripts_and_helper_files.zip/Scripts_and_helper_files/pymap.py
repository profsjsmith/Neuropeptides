# Define functions

import math
import time
import json
import scipy
import textwrap
import pymap as pm
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.colors as mcol
import matplotlib.patches as patches
import seaborn as sns
import ipywidgets as widgets
import io
import textwrap
import random
import xlsxwriter
import shutil
from scipy import stats
from matplotlib.patches import Rectangle, Polygon
from matplotlib.backends.backend_pdf import PdfPages
from PyPDF2 import PdfFileReader, PdfFileWriter
from fpdf import FPDF

# Serialized number string generator
def serial(pad): # generate a zero padded serial number string
    sn_file = 'SN.txt'
    f = open(sn_file, "r")
    n = int(f.read())    
    f = open(sn_file, "w")
    f.write(str(n+1))
    f.close()
    return str(n).zfill(pad)

# Convert text to a PDF file
def text_to_pdf(text, filename):
    fontsize_pts = 9
    pdf = FPDF(orientation='P', unit='in', format='Letter')
    pdf.set_left_margin(0.4); pdf.set_top_margin(0.7)
    pdf.set_auto_page_break(True, margin=0.7)
    pdf.add_page()
    pdf.set_font(family='Courier', size=fontsize_pts)
    splitted = text.split('\n')
    for line in splitted:
        lines = textwrap.wrap(line, 120) # max chars / line
        if len(lines) == 0: pdf.ln()
        for wrap in lines: pdf.cell(0, fontsize_pts/72, wrap, ln=1)
    pdf.output(filename, 'F')

# Shorten class, subclass, supertype or cluster label
def shortener(s):
    head = s.split(' ')[0]
    tail = s.split(' ')[-1]
    tail = tail.replace('Gaba','GABA')
    if tail != 'NN': return head+'_'+tail
    return head+'_'+s.split(' ')[1]

# Format list of decimals
def formatter(decimals_list):
    formatted = []
    for value in decimals_list:
        if value < 0.0001: formatted += '0'
        elif value < 0.01: formatted += ['{:,.4f}'.format(value)]
        elif value < 0.1: formatted += ['{:,.3f}'.format(value)]
        elif value < 1: formatted += ['{:,.2f}'.format(value)]
        elif value < 10: formatted += ['{:,.1f}'.format(value)]
        else: formatted += ['{:,.0f}'.format(value)]
    return formatted

def draw_heatmap(X, cells, colors, title_text, pdf, log=True, log_floor_coef=0.01, row_stat='max',
                 row_norm=True, row_sort=False, xticklabels=1, yticklabels=1, slant=70,
                 units='', hlines=None, vlines=None, cbar=False, cbar_label='', cbar_ticks=None):

    # Create cmap to handle Nan values
    base_cmap = sns.color_palette('rocket', as_cmap=True)
    new_cmap = mcol.ListedColormap(base_cmap(np.linspace(0, 1, 256)))
    new_cmap.set_bad('lightgray')
    
    # Function to calculate tangent of angle from horizontal in degrees
    htan = lambda x : math.tan(math.radians(90-x)) 

    if row_stat == 'max':
        X['Row_Stat'] = X.max(axis=1)
        stat_label = 'Row\nMax            '
        cbar_suffix = ' / Row_Max'
    if row_stat == 'mean':
        X['Row_Stat'] = X.mean(axis=1)
        stat_label = 'Row\nMean            '
        cbar_suffix = ' / Row_Mean'
    if row_stat == 'sum':
        X['Row_Stat'] = X.sum(axis=1)
        stat_label = 'Row\nSum            '
        cbar_suffix = ' / Row_Sum'
    
    if row_sort == True:
        X.sort_values(by='Row_Stat', ascending=False, inplace=True)
    
    f = dict(zip(X.index, X['Row_Stat']))
    row_stats = X.pop('Row_Stat')
    
    rows, cols = X.shape
    if hlines == None or row_sort == True: hlines = [0,rows]
    if vlines == None: vlines = [0,cols]
    
    #fig, ax = plt.subplots(figsize=(max(1+cols/4,8),max(1+rows/4,10)), layout="tight")
    fig, ax = plt.subplots(figsize=(max(1+cols/3,10),max(1+rows/3,12)), layout="tight")

    plt.subplots_adjust(left=0, right=1.0, bottom=0.0, top=1.0)
    df = X.copy()

    if row_norm == True:
        row_max = df.max(axis=1)
        df = df.divide(row_max, axis=0).fillna(0)
        cbar_label += cbar_suffix
    
    if log:
        log_floor = log_floor_coef * df.max().max()
        floor_str = str(formatter([log_floor]))[2:-2]
        df = np.log10(df+log_floor)
        cbar_kws={'shrink':0.25,'pad':0.175,'aspect':14, 'label':'log10('+cbar_label+' + '+floor_str+')',
                  'extend':'min', 'location':'bottom', 'orientation':'horizontal', 'ticks':cbar_ticks}
        vmin = None
    else:
        cbar_kws={'shrink':0.25,'pad':0.175,'aspect':14, 'label':cbar_label, 'location':'bottom',
                    'orientation':'horizontal', 'ticks':cbar_ticks}
        vmin = 0

    sns.heatmap(df, ax=ax, cmap=new_cmap, square=True, vmin=vmin,
                xticklabels=xticklabels, yticklabels=yticklabels, cbar=cbar, cbar_kws=cbar_kws)
    
    if cbar:
        cbar = ax.collections[0].colorbar
        cbar.outline.set_edgecolor('blue')
        cbar.outline.set_linewidth(1)
        if log and units==' %': # Special case
            cbar.set_label(cbar_label)
            cbar.set_ticks([0, 0.5, 1], labels= ['0','50','100'])

    # Set up column labels and colors, and class division lines
    labels = list(X.columns)        

    # Set up page label
    plt.xlabel(title_text, labelpad=24)

    # label top axis ticks with region/subclass labels 
    ax.tick_params(axis='x', length=0, labelrotation=slant, pad=0) 
    n = 8
    ax.set_xticklabels([n*' '+label for label in labels], ha='left', va='center',
                       rotation_mode='anchor') 
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')

    # Label left axis with gene symbols
    ax.tick_params(axis='y', length=0, pad=8, labelrotation=0)
    #ax.set_yticklabels(list(X.index), ha='right', va='center' ,style='italic')
    ax.set_yticks(np.arange(0.5, rows+0.5), labels = list(X.index), va='center_baseline' , style='italic')
    #{'baseline', 'bottom', 'center', 'center_baseline', 'top'}
    ax.text(-1.5, -1.5, '           Gene\nSymbol', ha='right', va='center')

    # Label bottom axis ticks with cell counts
    labels = list(cells.map('{:,.0f}'.format)) # Cell numbers
    secax_x = ax.secondary_xaxis(0.0)
    secax_x.set_xticks(np.arange(0.2, len(cells)+0.2), labels=labels, ha='left') 
    secax_x.tick_params(axis='x', length=0, pad=24, labelrotation=90)
    secax_x.spines['bottom'].set_visible(False)
    secax_x.set_xlabel('Cell Tallies', labelpad=10)

    # Label rows on right axis
    labels = [s+units for s in formatter(row_stats)]
    secax_y = ax.secondary_yaxis(1.0)
    secax_y.set_yticks(np.arange(0.5, len(row_stats)+0.5), labels = labels)
    secax_y.tick_params(axis='y', length=0, pad=8, labelrotation=0)
    ax.text(cols+1.5, -1.5, stat_label, ha='left', va='center')

    # Draw top/bottom axis color patches
    for i, color in enumerate(colors):
        #h = 1 if rows>=20 else rows/20
        h = 1 # 0.6
        dx =  h * htan(slant)
        # Draw top patches
        patch = Polygon([(i,0), (i+dx,-h), (i+dx+1,-h), (i+1,0), (i,0)], facecolor=color, zorder=0)
        ax.add_patch(patch).set_clip_on(False)
        # Draw bottom patches
        patch = Polygon([(i,rows), (i,rows+h), (i+1,rows+h), (i+1,rows), (i,rows)], facecolor=color, zorder=0)
        ax.add_patch(patch).set_clip_on(False)

    # Draw horizontal lines
    ax.hlines(hlines, -0.5, cols+0.5, colors='blue', linewidths=2).set_clip_on(False)
    
    # Draw vertical lines
    ax.vlines(vlines, 0, rows+1.5, colors='blue', linewidths=2).set_clip_on(False)
    h = 1.5; dx =  h * htan(slant)
    for x in vlines: plt.plot([x,x+dx], [0,-h], clip_on=False, c='blue', lw=2)

    if pdf != None: pdf.savefig(dpi=300, transparent=True, bbox_inches='tight', pad_inches=0.2)
    plt.show()
    
    #return X
    return pd.DataFrame(list(row_stats), index=X.index, columns=['row '+row_stat])
    